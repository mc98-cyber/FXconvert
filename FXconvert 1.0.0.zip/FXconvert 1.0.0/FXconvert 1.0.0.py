import requests


text = """

Which currency would you like to convert to?

1) Dollar
2) Krona
3) Franc
"""

Anfrage   = float(input("How many Euros would you like to convert? "))
Anfrage_2 = str(input(text))

### API URLs

dollar_url = "https://api.frankfurter.app/latest?from=EUR&to=USD"
kronen_url = "https://api.frankfurter.app/latest?from=EUR&to=SEK"
franken_url = "https://api.frankfurter.app/latest?from=EUR&to=CHF"

response_1 = requests.get(dollar_url)
response_2 = requests.get(kronen_url)
response_3 = requests.get(franken_url)


if Anfrage_2 == "1" and response_1.status_code == 200:
    dollar_data = response_1.json()
    wechselkurs_dollar = dollar_data["rates"]["USD"]
    Datum_dollar = dollar_data["date"]
    Eingabe_dollar = Anfrage * wechselkurs_dollar
    print(Anfrage, " Euros are equivalent to (as of ", Datum_dollar, ") ", Eingabe_dollar)

elif Anfrage_2 == "2" and response_2.status_code == 200:
    kronen_data = response_2.json()
    wechselkurs_kronen = kronen_data["rates"]["SEK"]
    Datum_kronen = kronen_data["date"]
    Eingabe_kronen = Anfrage * wechselkurs_kronen
    print(Anfrage, " Euros are equivalent to (as of ", Datum_kronen, ") ", Eingabe_kronen)

elif Anfrage_2 == "3" and response_3.status_code == 200:
    franken_data = response_3.json()
    wechselkurs_franken = franken_data["rates"]["CHF"]
    Datum_franken = franken_data["date"]
    Eingabe_franken = Anfrage * wechselkurs_franken
    print(Anfrage, " Euros are equivalent to (as of ", Datum_franken, ") ", Eingabe_franken)

else:
    print("Invalid input or connection error.")